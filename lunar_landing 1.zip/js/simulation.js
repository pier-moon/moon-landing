/**
 * Lunar Lander Simulation
 * This script handles the physics calculations and animation for the lunar landing simulation
 */

// Constants
const MOON_GRAVITY = 1.66; // m/s²
const MOON_MASS = 7.348e22; // kg
const EARTH_MASS = 5.976e24; // kg
const EARTH_MOON_DISTANCE = 3.84e8; // m
const EARTH_GRAVITY = 9.81; // m/s²
const G = 6.67430e-11; // Gravitational constant in m³/kg/s²

// Classes
class LunarLander {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        this.reset();
        this.initializeStars();
        this.createSpacecraftImage();
    }

    reset() {
        // Simulation parameters
        this.isRunning = false;
        this.isPaused = false;
        this.timeElapsed = 0;
        this.shipMass = 0;
        this.initialVelocity = 0;
        this.currentVelocity = 0;
        this.position = 0;
        this.canvasHeight = this.canvas.height;
        this.startHeight = this.canvasHeight * 0.1; // Start at 10% from the top
        this.landingHeight = this.canvasHeight * 0.9; // Land at 90% from the top (near the bottom)
        this.distanceToTravel = this.landingHeight - this.startHeight;
        this.currentHeight = this.startHeight;
        this.scaleFactor = 1; // Used to scale the visualization
        this.landingTime = 0;
        
        // Animation timing
        this.lastFrameTime = 0;
        this.timeScale = 1; // For speed control
        
        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }

    initializeStars() {
        this.stars = [];
        const numberOfStars = 100;
        
        for (let i = 0; i < numberOfStars; i++) {
            this.stars.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * this.canvas.height * 0.9, // Keep stars above the moon surface
                size: Math.random() * 2 + 1,
                twinkleSpeed: Math.random() * 0.03 + 0.01
            });
        }
    }

    createSpacecraftImage() {
        // Create a simple spacecraft shape
        this.spacecraftImage = new Image();
        this.spacecraftImage.src = './img/spacecraft.png';
        
        // Fallback if image doesn't load
        this.spacecraftImage.onerror = () => {
            console.warn('Spacecraft image failed to load. Using fallback shape.');
            this.useImageFallback = true;
        };
    }

    // Set up the simulation with user provided values
    setup(mass, initialVelocity) {
        this.reset();
        this.shipMass = parseFloat(mass);
        this.initialVelocity = parseFloat(initialVelocity);
        this.currentVelocity = this.initialVelocity;
        
        // Calculate expected landing time for progress tracking
        // Using the kinematic equation: d = v₀t + (1/2)at²
        // Solving for t: t = (-v₀ + √(v₀² + 2ad)) / a
        const a = MOON_GRAVITY;
        const v0 = this.initialVelocity;
        const d = this.distanceToTravel / this.scaleFactor; // Convert canvas distance to actual distance
        
        // Check if we need a special case for zero initial velocity
        if (v0 === 0) {
            this.landingTime = Math.sqrt(2 * d / a);
        } else {
            // For initial velocity downward (positive), we add to gravity
            this.landingTime = (Math.sqrt(v0 * v0 + 2 * a * d) - v0) / a;
        }

        // Validate the landing time
        if (isNaN(this.landingTime) || !isFinite(this.landingTime) || this.landingTime <= 0) {
            console.error('Invalid landing time calculated, using default.');
            this.landingTime = 10; // Default to 10 seconds
        }
        
        console.log(`Landing time calculated: ${this.landingTime.toFixed(2)} seconds`);
        return this.landingTime;
    }

    // Start the simulation animation
    start() {
        if (!this.isRunning) {
            this.isRunning = true;
            this.isPaused = false;
            this.lastFrameTime = performance.now();
            requestAnimationFrame(this.animate.bind(this));
        } else if (this.isPaused) {
            this.isPaused = false;
            this.lastFrameTime = performance.now();
            requestAnimationFrame(this.animate.bind(this));
        }
    }

    // Pause the simulation
    pause() {
        this.isPaused = true;
    }

    // Continue simulation from current state
    resume() {
        if (this.isRunning && this.isPaused) {
            this.isPaused = false;
            this.lastFrameTime = performance.now();
            requestAnimationFrame(this.animate.bind(this));
        }
    }

    // Stop the simulation
    stop() {
        this.isRunning = false;
        this.isPaused = false;
    }

    // Main animation loop
    animate(currentTime) {
        if (!this.isRunning || this.isPaused) return;
        
        // Calculate time delta
        const deltaTime = (currentTime - this.lastFrameTime) / 1000; // Convert to seconds
        this.lastFrameTime = currentTime;
        
        // Update simulation
        this.update(deltaTime * this.timeScale);
        this.render();
        
        // Check if landing occurred
        if (this.currentHeight >= this.landingHeight) {
            this.currentHeight = this.landingHeight; // Snap to surface
            this.isRunning = false;
            this.renderFinalState();
            
            // Dispatch event to notify completion
            const landingEvent = new CustomEvent('landing-completed', {
                detail: {
                    time: this.timeElapsed,
                    velocity: this.currentVelocity
                }
            });
            document.dispatchEvent(landingEvent);
            return;
        }
        
        // Continue animation
        requestAnimationFrame(this.animate.bind(this));
    }

    // Update simulation state
    update(deltaTime) {
        // Increment time
        this.timeElapsed += deltaTime;
        
        // Apply lunar gravity to update velocity
        this.currentVelocity += MOON_GRAVITY * deltaTime;
        
        // Update position based on velocity
        const distanceMoved = this.currentVelocity * deltaTime;
        this.currentHeight += distanceMoved;
        
        // Calculate progress percentage
        this.progress = Math.min(this.timeElapsed / this.landingTime, 1);
    }

    // Render the current state to canvas
    render() {
        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw background
        this.drawBackground();
        
        // Draw spacecraft
        this.drawSpacecraft();
        
        // Draw moon surface
        this.drawMoonSurface();
        
        // Draw UI elements (timer, distance, velocity)
        this.drawUI();
    }

    // Draw final state after landing
    renderFinalState() {
        this.render(); // Draw normal state first
        
        // Add landing message
        this.ctx.fillStyle = 'white';
        this.ctx.font = 'bold 24px Arial';
        this.ctx.textAlign = 'center';
        
        const isSafeLanding = Math.abs(this.currentVelocity) < 5; // Safe landing if velocity < 5 m/s
        
        if (isSafeLanding) {
            this.ctx.fillStyle = '#4caf50'; // Green text for safe landing
            this.ctx.fillText('LANDING SUCCESSFUL', this.canvas.width / 2, this.canvas.height / 2);
        } else {
            this.ctx.fillStyle = '#f44336'; // Red text for crash
            this.ctx.fillText('LANDING FAILED - SPACECRAFT DAMAGED', this.canvas.width / 2, this.canvas.height / 2);
        }
        
        // Show landing statistics
        this.ctx.font = '16px Arial';
        this.ctx.fillStyle = 'white';
        this.ctx.fillText(`Landing Time: ${this.timeElapsed.toFixed(2)} seconds`, this.canvas.width / 2, this.canvas.height / 2 + 30);
        this.ctx.fillText(`Landing Velocity: ${this.currentVelocity.toFixed(2)} m/s`, this.canvas.width / 2, this.canvas.height / 2 + 55);
    }

    // Draw stars and space background
    drawBackground() {
        // Draw black space
        this.ctx.fillStyle = '#0a0a2a';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw stars
        this.ctx.fillStyle = 'white';
        for (const star of this.stars) {
            const twinkle = Math.sin(this.timeElapsed * star.twinkleSpeed * 10) * 0.5 + 0.5;
            this.ctx.globalAlpha = 0.3 + twinkle * 0.7;
            this.ctx.beginPath();
            this.ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
            this.ctx.fill();
        }
        this.ctx.globalAlpha = 1;
        
        // Draw Earth in the distance (small blue dot with glow)
        this.ctx.fillStyle = '#1e88e5';
        this.ctx.shadowColor = '#64b5f6';
        this.ctx.shadowBlur = 15;
        this.ctx.beginPath();
        this.ctx.arc(this.canvas.width - 50, 50, 15, 0, Math.PI * 2);
        this.ctx.fill();
        this.ctx.shadowBlur = 0;
    }

    // Draw the spacecraft
    drawSpacecraft() {
        const x = this.canvas.width / 2;
        const y = this.currentHeight;
        
        // Draw spacecraft based on whether image loaded successfully
        if (this.useImageFallback) {
            // Fallback: Draw a simple rocket shape
            this.ctx.fillStyle = '#e0e0e0';
            this.ctx.beginPath();
            this.ctx.moveTo(x, y - 20);
            this.ctx.lineTo(x - 10, y + 10);
            this.ctx.lineTo(x + 10, y + 10);
            this.ctx.closePath();
            this.ctx.fill();
            
            // Draw thrusters
            this.ctx.fillStyle = '#ff9800';
            this.ctx.beginPath();
            this.ctx.moveTo(x - 5, y + 10);
            this.ctx.lineTo(x - 8, y + 20);
            this.ctx.lineTo(x - 2, y + 10);
            this.ctx.closePath();
            this.ctx.fill();
            
            this.ctx.beginPath();
            this.ctx.moveTo(x + 5, y + 10);
            this.ctx.lineTo(x + 8, y + 20);
            this.ctx.lineTo(x + 2, y + 10);
            this.ctx.closePath();
            this.ctx.fill();
        } else {
            // Use the spacecraft image
            const imgWidth = 40;
            const imgHeight = 60;
            
            if (this.spacecraftImage.complete) {
                this.ctx.drawImage(this.spacecraftImage, x - imgWidth/2, y - imgHeight/2, imgWidth, imgHeight);
            }
        }
        
        // Draw engine flames (length depends on velocity)
        if (this.initialVelocity < 0) { // Show flames only for upward initial velocity
            const flameLength = Math.min(20, Math.abs(this.initialVelocity) * 2);
            
            this.ctx.fillStyle = 'rgba(255, 165, 0, 0.7)';
            this.ctx.beginPath();
            this.ctx.moveTo(x - 5, y + 10);
            this.ctx.lineTo(x, y + 10 + flameLength);
            this.ctx.lineTo(x + 5, y + 10);
            this.ctx.closePath();
            this.ctx.fill();
        }
    }

    // Draw the moon surface
    drawMoonSurface() {
        // Create lunar surface gradient
        const gradient = this.ctx.createLinearGradient(0, this.landingHeight, 0, this.canvas.height);
        gradient.addColorStop(0, '#aaa9ad');
        gradient.addColorStop(1, '#83838b');
        
        // Draw main surface
        this.ctx.fillStyle = gradient;
        this.ctx.beginPath();
        this.ctx.moveTo(0, this.landingHeight);
        
        // Create uneven surface with hills
        for (let x = 0; x <= this.canvas.width; x += 20) {
            const height = this.landingHeight + Math.sin(x * 0.05) * 5 + Math.sin(x * 0.02) * 10;
            this.ctx.lineTo(x, height);
        }
        
        this.ctx.lineTo(this.canvas.width, this.canvas.height);
        this.ctx.lineTo(0, this.canvas.height);
        this.ctx.closePath();
        this.ctx.fill();
        
        // Add craters
        this.drawCraters();
        
        // Draw flat landing zone
        const padWidth = 100;
        const padX = this.canvas.width / 2 - padWidth / 2;
        
        this.ctx.fillStyle = '#b0bec5';
        this.ctx.fillRect(padX, this.landingHeight - 2, padWidth, 4);
    }

    // Draw lunar craters
    drawCraters() {
        // Add a few random craters
        this.ctx.fillStyle = '#83838b';
        
        // Use fixed positions for craters for consistency
        const craterPositions = [
            { x: 100, y: this.landingHeight + 20, size: 15 },
            { x: 300, y: this.landingHeight + 30, size: 25 },
            { x: 700, y: this.landingHeight + 15, size: 20 },
            { x: 500, y: this.landingHeight + 40, size: 30 },
            { x: 900, y: this.landingHeight + 25, size: 22 }
        ];
        
        for (const crater of craterPositions) {
            this.ctx.beginPath();
            this.ctx.arc(crater.x, crater.y, crater.size, 0, Math.PI * 2);
            this.ctx.fill();
            
            // Add highlight to create 3D effect
            this.ctx.fillStyle = '#9e9e9e';
            this.ctx.beginPath();
            this.ctx.arc(crater.x - 3, crater.y - 3, crater.size * 0.7, 0, Math.PI * 2);
            this.ctx.fill();
            
            this.ctx.fillStyle = '#83838b';
        }
    }

    // Draw UI elements on the canvas
    drawUI() {
        this.ctx.fillStyle = 'white';
        this.ctx.font = '14px Arial';
        this.ctx.textAlign = 'left';
        
        // Draw current time
        this.ctx.fillText(`Time: ${this.timeElapsed.toFixed(2)} s`, 20, 30);
        
        // Draw velocity
        this.ctx.fillText(`Velocity: ${this.currentVelocity.toFixed(2)} m/s`, 20, 55);
        
        // Draw height remaining
        const heightRemaining = (this.landingHeight - this.currentHeight) / 
                                (this.landingHeight - this.startHeight) * 100;
        this.ctx.fillText(`Height: ${Math.max(0, heightRemaining.toFixed(1))}%`, 20, 80);
        
        // Draw landing zone marker
        this.ctx.fillStyle = 'rgba(76, 175, 80, 0.5)';
        const landingZoneWidth = 100;
        this.ctx.fillRect(
            this.canvas.width / 2 - landingZoneWidth / 2, 
            this.landingHeight - 5,
            landingZoneWidth,
            10
        );
        
        // Progress bar at top of screen
        this.ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
        this.ctx.fillRect(20, 100, this.canvas.width - 40, 10);
        
        this.ctx.fillStyle = 'rgba(33, 150, 243, 0.7)';
        this.ctx.fillRect(20, 100, (this.canvas.width - 40) * this.progress, 10);
    }

    // Calculate gravitational force using Newton's formula
    calculateGravitationalForce(mass1, mass2, distance) {
        return (G * mass1 * mass2) / (distance * distance);
    }
}

// When DOM is loaded, initialize simulation
document.addEventListener('DOMContentLoaded', function() {
    // Get simulation canvas
    const canvas = document.getElementById('simulation-canvas');
    
    // Set canvas size to match its container
    function resizeCanvas() {
        const container = canvas.parentElement;
        canvas.width = container.clientWidth;
        canvas.height = container.clientHeight;
    }
    
    // Call once on init
    resizeCanvas();
    
    // Resize when window changes
    window.addEventListener('resize', resizeCanvas);
    
    // Create lunar lander instance
    const lunarLander = new LunarLander(canvas);
    
    // Store in window object for global access
    window.lunarLander = lunarLander;
    
    // Form submit handler
    const simulationForm = document.getElementById('simulation-form');
    if (simulationForm) {
        simulationForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const mass = document.getElementById('spacecraft-mass').value;
            const velocity = document.getElementById('initial-velocity').value;
            
            // Setup and start simulation
            const landingTime = lunarLander.setup(mass, velocity);
            
            // Update estimated landing time
            document.getElementById('estimated-time').textContent = landingTime.toFixed(2);
            
            // Show results panel
            document.getElementById('results-panel').style.display = 'block';
            
            // Start the simulation
            lunarLander.start();
        });
    }
    
    // Control button handlers
    // Note: We don't need a separate start button handler since the form submit handles it
    const pauseBtn = document.getElementById('pause-btn');
    const resetBtn = document.getElementById('reset-btn');
    
    if (pauseBtn) {
        pauseBtn.addEventListener('click', function() {
            if (lunarLander.isPaused) {
                lunarLander.resume();
                pauseBtn.textContent = 'Pause';
            } else {
                lunarLander.pause();
                pauseBtn.textContent = 'Resume';
            }
        });
    }
    
    if (resetBtn) {
        resetBtn.addEventListener('click', function() {
            lunarLander.stop();
            
            // Reset form if it exists
            if (simulationForm) {
                simulationForm.reset();
            }
            
            // Hide results panel
            document.getElementById('results-panel').style.display = 'none';
            
            // Reset the simulation
            lunarLander.reset();
            
            // Reset pause button text
            if (pauseBtn) {
                pauseBtn.textContent = 'Pause';
            }
        });
    }
    
    // Handle landing completed event
    document.addEventListener('landing-completed', function(e) {
        const landingTime = e.detail.time;
        const landingVelocity = e.detail.velocity;
        
        // Update results
        document.getElementById('actual-time').textContent = landingTime.toFixed(2);
        document.getElementById('landing-velocity').textContent = landingVelocity.toFixed(2);
        
        // Determine if landing was successful
        const isSafeLanding = Math.abs(landingVelocity) < 5;
        const landingStatus = isSafeLanding ? 'Success' : 'Crash';
        document.getElementById('landing-status').textContent = landingStatus;
        document.getElementById('landing-status').className = 
            isSafeLanding ? 'status-success' : 'status-failure';
            
        // Save the landing result to the database if available
        if (window.lunarDB && typeof window.lunarDB.saveLandingResult === 'function') {
            try {
                // Get current simulation values
                const mass = document.getElementById('spacecraft-mass').value;
                const initialVelocity = document.getElementById('initial-velocity').value;
                
                // Save to database
                const resultId = window.lunarDB.saveLandingResult({
                    mass: parseFloat(mass),
                    initialVelocity: parseFloat(initialVelocity),
                    landingTime: landingTime,
                    landingVelocity: landingVelocity,
                    successful: isSafeLanding
                });
                
                console.log('Landing result saved with ID:', resultId);
                
                // Get updated statistics
                const stats = window.lunarDB.getLandingStatistics();
                console.log('Updated landing statistics:', stats);
            } catch (error) {
                console.error('Failed to save landing result:', error);
            }
        }
    });
    
    // Create initial static view
    lunarLander.render();
});