/**
 * Database functions for lunar landing simulation
 * This handles storing and retrieving landing attempts
 */

// Use localStorage for persistent storage in the browser
const DB_KEY = 'lunar_landing_results';

/**
 * Save a landing attempt to the database
 * @param {Object} result - The landing result to save
 * @param {number} result.mass - Spacecraft mass in kg
 * @param {number} result.initialVelocity - Initial velocity in m/s
 * @param {number} result.landingTime - Actual landing time in seconds
 * @param {number} result.landingVelocity - Final velocity at landing in m/s
 * @param {boolean} result.successful - Whether the landing was successful
 * @returns {string} The ID of the saved record
 */
function saveLandingResult(result) {
    // Add timestamp and generate unique ID
    const record = {
        ...result,
        id: generateId(),
        timestamp: new Date().toISOString()
    };
    
    // Get existing records
    const records = getAllLandingResults();
    
    // Add new record
    records.push(record);
    
    // Save back to localStorage
    localStorage.setItem(DB_KEY, JSON.stringify(records));
    
    return record.id;
}

/**
 * Retrieve all landing results from the database
 * @returns {Array} Array of landing result objects
 */
function getAllLandingResults() {
    const data = localStorage.getItem(DB_KEY);
    return data ? JSON.parse(data) : [];
}

/**
 * Get a specific landing result by ID
 * @param {string} id - The ID of the landing result to retrieve
 * @returns {Object|null} The landing result or null if not found
 */
function getLandingResultById(id) {
    const records = getAllLandingResults();
    return records.find(record => record.id === id) || null;
}

/**
 * Delete a landing result from the database
 * @param {string} id - The ID of the landing result to delete
 * @returns {boolean} True if the record was deleted, false otherwise
 */
function deleteLandingResult(id) {
    const records = getAllLandingResults();
    const initialLength = records.length;
    
    const filteredRecords = records.filter(record => record.id !== id);
    
    if (filteredRecords.length !== initialLength) {
        localStorage.setItem(DB_KEY, JSON.stringify(filteredRecords));
        return true;
    }
    
    return false;
}

/**
 * Clear all landing results from the database
 * @returns {void}
 */
function clearAllLandingResults() {
    localStorage.removeItem(DB_KEY);
}

/**
 * Get statistics on all landing attempts
 * @returns {Object} Statistics about landing attempts
 */
function getLandingStatistics() {
    const records = getAllLandingResults();
    
    if (records.length === 0) {
        return {
            totalAttempts: 0,
            successfulLandings: 0,
            crashLandings: 0,
            successRate: 0,
            averageLandingTime: 0,
            averageLandingVelocity: 0
        };
    }
    
    const successfulLandings = records.filter(r => r.successful).length;
    
    return {
        totalAttempts: records.length,
        successfulLandings,
        crashLandings: records.length - successfulLandings,
        successRate: (successfulLandings / records.length) * 100,
        averageLandingTime: average(records.map(r => r.landingTime)),
        averageLandingVelocity: average(records.map(r => Math.abs(r.landingVelocity)))
    };
}

// Utility functions
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substring(2);
}

function average(arr) {
    return arr.reduce((sum, val) => sum + val, 0) / arr.length;
}

// Export database functions
window.lunarDB = {
    saveLandingResult,
    getAllLandingResults,
    getLandingResultById,
    deleteLandingResult,
    clearAllLandingResults,
    getLandingStatistics
};